/*
 * MIT License
 * Copyright (c) 2019 _VIFEXTech
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include "gpio.h"

const PinInfo_TypeDef PIN_MAP[PIN_MAX] =
{
    /*GPIO_TypeDef* GPIOx;  //对应GPIOx地址
    TIM_TypeDef* TIMx;      //对应TIMx地址
    ADC_TypeDef* ADCx;      //对应ADCx地址

    uint16_t GPIO_PIN_X;    //对应GPIO_Pin位
    uint8_t TimerChannel;   //对应定时器通道
    uint8_t ADC_Channel;*/  //对应ADC通道
#ifdef GPIOA
    {GPIOA, TIM2, ADC1,  GPIO_PIN_0, 1, ADC_CHANNEL_0}, /* PA0 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_1, 2, ADC_CHANNEL_1}, /* PA1 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_2, 3, ADC_CHANNEL_2}, /* PA2 */
    {GPIOA, TIM2, ADC1,  GPIO_PIN_3, 4, ADC_CHANNEL_3}, /* PA3 */
    {GPIOA, NULL, ADC1,  GPIO_PIN_4, 0, ADC_CHANNEL_4}, /* PA4 */
    {GPIOA, NULL, ADC1,  GPIO_PIN_5, 0, ADC_CHANNEL_5}, /* PA5 */
    {GPIOA, TIM3, ADC1,  GPIO_PIN_6, 1, ADC_CHANNEL_6}, /* PA6 */
    {GPIOA, TIM3, ADC1,  GPIO_PIN_7, 2, ADC_CHANNEL_7}, /* PA7 */
    {GPIOA, TIM1, NULL,  GPIO_PIN_8, 1, ADC_CHANNEL_X}, /* PA8 */
    {GPIOA, TIM1, NULL,  GPIO_PIN_9, 2, ADC_CHANNEL_X}, /* PA9 */
    {GPIOA, TIM1, NULL, GPIO_PIN_10, 3, ADC_CHANNEL_X}, /* PA10 */
    {GPIOA, TIM1, NULL, GPIO_PIN_11, 4, ADC_CHANNEL_X}, /* PA11 */
    {GPIOA, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PA12 */
    {GPIOA, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PA13 */
    {GPIOA, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PA14 */
    {GPIOA, TIM2, NULL, GPIO_PIN_15, 1, ADC_CHANNEL_X}, /* PA15 */
#endif
#ifdef GPIOB
    {GPIOB, TIM3, ADC1,  GPIO_PIN_0, 3, ADC_CHANNEL_8}, /* PB0 */
    {GPIOB, TIM3, ADC1,  GPIO_PIN_1, 4, ADC_CHANNEL_9}, /* PB1 */
    {GPIOB, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PB2 */
    {GPIOB, TIM2, NULL,  GPIO_PIN_3, 2, ADC_CHANNEL_X}, /* PB3 */
    {GPIOB, TIM3, NULL,  GPIO_PIN_4, 1, ADC_CHANNEL_X}, /* PB4 */
    {GPIOB, TIM3, NULL,  GPIO_PIN_5, 2, ADC_CHANNEL_X}, /* PB5 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_6, 1, ADC_CHANNEL_X}, /* PB6 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_7, 2, ADC_CHANNEL_X}, /* PB7 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_8, 3, ADC_CHANNEL_X}, /* PB8 */
    {GPIOB, TIM4, NULL,  GPIO_PIN_9, 4, ADC_CHANNEL_X}, /* PB9 */
    {GPIOB, TIM2, NULL, GPIO_PIN_10, 3, ADC_CHANNEL_X}, /* PB10 */
    {GPIOB, TIM2, NULL, GPIO_PIN_11, 4, ADC_CHANNEL_X}, /* PB11 */
    {GPIOB, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PB12 */
    {GPIOB, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PB13 */
    {GPIOB, TIM12, NULL, GPIO_PIN_14, 1, ADC_CHANNEL_X},/* PB14 */
    {GPIOB, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PB15 */
#endif
#ifdef GPIOC
    {GPIOC, NULL, ADC1,  GPIO_PIN_0, 0, ADC_CHANNEL_10},/* PC0 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_1, 0, ADC_CHANNEL_11},/* PC1 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_2, 0, ADC_CHANNEL_12},/* PC2 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_3, 0, ADC_CHANNEL_13},/* PC3 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_4, 0, ADC_CHANNEL_14},/* PC4 */
    {GPIOC, NULL, ADC1,  GPIO_PIN_5, 0, ADC_CHANNEL_15},/* PC5 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_6, 1, ADC_CHANNEL_X}, /* PC6 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_7, 2, ADC_CHANNEL_X}, /* PC7 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_8, 3, ADC_CHANNEL_X}, /* PC8 */
    {GPIOC, TIM3, NULL,  GPIO_PIN_9, 4, ADC_CHANNEL_X}, /* PC9 */
    {GPIOC, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PC10 */
    {GPIOC, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PC11 */
    {GPIOC, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PC12 */
    {GPIOC, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PC13 */
    {GPIOC, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PC14 */
    {GPIOC, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PC15 */
#endif
#ifdef GPIOD
    {GPIOD, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PD0 */
    {GPIOD, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PD1 */
    {GPIOD, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PD2 */
    {GPIOD, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PD3 */
    {GPIOD, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PD4 */
    {GPIOD, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PD5 */
    {GPIOD, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PD6 */
    {GPIOD, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PD7 */
    {GPIOD, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PD8 */
    {GPIOD, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PD9 */
    {GPIOD, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PD10 */
    {GPIOD, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PD11 */
    {GPIOD, TIM4, NULL, GPIO_PIN_12, 1, ADC_CHANNEL_X}, /* PD12 */
    {GPIOD, TIM4, NULL, GPIO_PIN_13, 2, ADC_CHANNEL_X}, /* PD13 */
    {GPIOD, TIM4, NULL, GPIO_PIN_14, 3, ADC_CHANNEL_X}, /* PD14 */
    {GPIOD, TIM4, NULL, GPIO_PIN_15, 4, ADC_CHANNEL_X}, /* PD15 */
#endif
#ifdef GPIOE
    {GPIOE, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PE0 */
    {GPIOE, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PE1 */
    {GPIOE, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PE2 */
    {GPIOE, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PE3 */
    {GPIOE, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PE4 */
    {GPIOE, TIM9, NULL,  GPIO_PIN_5, 1, ADC_CHANNEL_X}, /* PE5 */
    {GPIOE, TIM9, NULL,  GPIO_PIN_6, 2, ADC_CHANNEL_X}, /* PE6 */
    {GPIOE, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PE7 */
    {GPIOE, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PE8 */
    {GPIOE, TIM1, NULL,  GPIO_PIN_9, 1, ADC_CHANNEL_X}, /* PE9 */
    {GPIOE, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PE10 */
    {GPIOE, TIM1, NULL, GPIO_PIN_11, 2, ADC_CHANNEL_X}, /* PE11 */
    {GPIOE, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PE12 */
    {GPIOE, TIM1, NULL, GPIO_PIN_13, 3, ADC_CHANNEL_X}, /* PE13 */
    {GPIOE, TIM1, NULL, GPIO_PIN_14, 4, ADC_CHANNEL_X}, /* PE14 */
    {GPIOE, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PE15 */
#endif
#ifdef GPIOF
    {GPIOF, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PF0 */
    {GPIOF, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PF1 */
    {GPIOF, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PF2 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_3, 0, ADC_CHANNEL_9}, /* PF3 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_4, 0, ADC_CHANNEL_14},/* PF4 */
    {GPIOF, NULL, ADC3,  GPIO_PIN_5, 0, ADC_CHANNEL_15},/* PF5 */
    {GPIOF, TIM10, ADC3,  GPIO_PIN_6, 1, ADC_CHANNEL_4}, /* PF6 */
    {GPIOF, TIM11, ADC3,  GPIO_PIN_7, 1, ADC_CHANNEL_5}, /* PF7 */
    {GPIOF, TIM13, ADC3,  GPIO_PIN_8, 1, ADC_CHANNEL_6}, /* PF8 */
    {GPIOF, TIM14, ADC3,  GPIO_PIN_9, 1, ADC_CHANNEL_7}, /* PF9 */
    {GPIOF, NULL, ADC3, GPIO_PIN_10, 0, ADC_CHANNEL_8}, /* PF10 */
    {GPIOF, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PF11 */
    {GPIOF, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PF12 */
    {GPIOF, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PF13 */
    {GPIOF, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PF14 */
    {GPIOF, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PF15 */
#endif
#ifdef GPIOG
    {GPIOG, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PG0 */
    {GPIOG, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PG1 */
    {GPIOG, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PG2 */
    {GPIOG, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PG3 */
    {GPIOG, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PG4 */
    {GPIOG, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PG5 */
    {GPIOG, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PG6 */
    {GPIOG, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PG7 */
    {GPIOG, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PG8 */
    {GPIOG, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PG9 */
    {GPIOG, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PG10 */
    {GPIOG, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PG11 */
    {GPIOG, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PG12 */
    {GPIOG, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PG13 */
    {GPIOG, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PG14 */
    {GPIOG, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PG15 */
#endif
#ifdef GPIOH
    {GPIOH, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PH0 */
    {GPIOH, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PH1 */
    {GPIOH, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PH2 */
    {GPIOH, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PH3 */
    {GPIOH, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PH4 */
    {GPIOH, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PH5 */
    {GPIOH, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PH6 */
    {GPIOH, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PH7 */
    {GPIOH, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PH8 */
    {GPIOH, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PH9 */
    {GPIOH, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PH10 */
    {GPIOH, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PH11 */
    {GPIOH, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PH12 */
    {GPIOH, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PH13 */
    {GPIOH, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PH14 */
    {GPIOH, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PH15 */
#endif
#ifdef GPIOI
    {GPIOI, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PI0 */
    {GPIOI, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PI1 */
    {GPIOI, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PI2 */
    {GPIOI, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PI3 */
    {GPIOI, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PI4 */
    {GPIOI, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PI5 */
    {GPIOI, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PI6 */
    {GPIOI, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PI7 */
    {GPIOI, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PI8 */
    {GPIOI, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PI9 */
    {GPIOI, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PI10 */
    {GPIOI, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PI11 */
    {GPIOI, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PI12 */
    {GPIOI, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PI13 */
    {GPIOI, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PI14 */
    {GPIOI, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PI15 */
#endif
#ifdef GPIOJ
    {GPIOJ, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PJ0 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PJ1 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PJ2 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PJ3 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PJ4 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PJ5 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PJ6 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PJ7 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PJ8 */
    {GPIOJ, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PJ9 */
    {GPIOJ, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PJ10 */
    {GPIOJ, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PJ11 */
    {GPIOJ, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PJ12 */
    {GPIOJ, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PJ13 */
    {GPIOJ, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PJ14 */
    {GPIOJ, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PJ15 */
#endif
#ifdef GPIOK
    {GPIOK, NULL, NULL,  GPIO_PIN_0, 0, ADC_CHANNEL_X}, /* PK0 */
    {GPIOK, NULL, NULL,  GPIO_PIN_1, 0, ADC_CHANNEL_X}, /* PK1 */
    {GPIOK, NULL, NULL,  GPIO_PIN_2, 0, ADC_CHANNEL_X}, /* PK2 */
    {GPIOK, NULL, NULL,  GPIO_PIN_3, 0, ADC_CHANNEL_X}, /* PK3 */
    {GPIOK, NULL, NULL,  GPIO_PIN_4, 0, ADC_CHANNEL_X}, /* PK4 */
    {GPIOK, NULL, NULL,  GPIO_PIN_5, 0, ADC_CHANNEL_X}, /* PK5 */
    {GPIOK, NULL, NULL,  GPIO_PIN_6, 0, ADC_CHANNEL_X}, /* PK6 */
    {GPIOK, NULL, NULL,  GPIO_PIN_7, 0, ADC_CHANNEL_X}, /* PK7 */
    {GPIOK, NULL, NULL,  GPIO_PIN_8, 0, ADC_CHANNEL_X}, /* PK8 */
    {GPIOK, NULL, NULL,  GPIO_PIN_9, 0, ADC_CHANNEL_X}, /* PK9 */
    {GPIOK, NULL, NULL, GPIO_PIN_10, 0, ADC_CHANNEL_X}, /* PK10 */
    {GPIOK, NULL, NULL, GPIO_PIN_11, 0, ADC_CHANNEL_X}, /* PK11 */
    {GPIOK, NULL, NULL, GPIO_PIN_12, 0, ADC_CHANNEL_X}, /* PK12 */
    {GPIOK, NULL, NULL, GPIO_PIN_13, 0, ADC_CHANNEL_X}, /* PK13 */
    {GPIOK, NULL, NULL, GPIO_PIN_14, 0, ADC_CHANNEL_X}, /* PK14 */
    {GPIOK, NULL, NULL, GPIO_PIN_15, 0, ADC_CHANNEL_X}, /* PK15 */
#endif
};

/**
  * @brief  GPIO初始化
  * @param  GPIOx: GPIO地址
  * @param  GPIO_PIN_X: GPIO对应位
  * @param  GPIO_Mode_x: GPIO模式
  * @param  GPIO_Speed_x: GPIO速度
  * @retval 无
  */
void GPIOx_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN_X, pinMode_TypeDef pinMode_x, uint32_t GPIO_Speed_x)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
//    uint32_t RCC_AHB1Periph_GPIOx;
//    GPIOMode_TypeDef GPIO_Mode_x;
//    GPIOOType_TypeDef GPIO_OType_x;
//    GPIOPuPd_TypeDef GPIO_PuPd_x;
    uint32_t GPIO_Mode_x;	//对应Mode
    uint32_t GPIO_OType_x;	//对应Mode
    uint32_t GPIO_PuPd_x;	//对应Pull

//  使能GPIOx所在的时钟
    if(0);
#ifdef GPIOA
    else if(GPIOx == GPIOA)__HAL_RCC_GPIOA_CLK_ENABLE();
#endif
#ifdef GPIOB
    else if(GPIOx == GPIOB)__HAL_RCC_GPIOB_CLK_ENABLE();
#endif
#ifdef GPIOC
    else if(GPIOx == GPIOC)__HAL_RCC_GPIOC_CLK_ENABLE();
#endif
#ifdef GPIOD
    else if(GPIOx == GPIOD)__HAL_RCC_GPIOD_CLK_ENABLE();
#endif
#ifdef GPIOE
    else if(GPIOx == GPIOE)__HAL_RCC_GPIOE_CLK_ENABLE();
#endif
#ifdef GPIOF
    else if(GPIOx == GPIOF)__HAL_RCC_GPIOF_CLK_ENABLE();
#endif
#ifdef GPIOG
    else if(GPIOx == GPIOG)__HAL_RCC_GPIOG_CLK_ENABLE();
#endif
#ifdef GPIOH
    else if(GPIOx == GPIOH)__HAL_RCC_GPIOH_CLK_ENABLE();
#endif
#ifdef GPIOI
    else if(GPIOx == GPIOI)__HAL_RCC_GPIOI_CLK_ENABLE();
#endif
#ifdef GPIOJ
    else if(GPIOx == GPIOJ)__HAL_RCC_GPIOJ_CLK_ENABLE();
#endif
#ifdef GPIOK
    else if(GPIOx == GPIOK)__HAL_RCC_GPIOK_CLK_ENABLE();
#endif
    else return;


    if(pinMode_x == INPUT)
    {
        GPIO_Mode_x  = MODE_INPUT;
        GPIO_PuPd_x  = GPIO_NOPULL;	//GPIO_NOPULL不上拉不下拉,输出时与OUTPUT_PP推完模式一起用，但这里是输入
    }
    else if(pinMode_x == INPUT_PULLUP)
    {
        GPIO_Mode_x  = MODE_INPUT;
        GPIO_PuPd_x  = GPIO_PULLUP;
    }
    else if(pinMode_x == INPUT_PULLDOWN)
    {
        GPIO_Mode_x  = MODE_INPUT;
        GPIO_PuPd_x  = GPIO_PULLDOWN;
    }
#ifdef HAL_ADC_MODULE_ENABLED
    else if(pinMode_x == INPUT_ANALOG)
    {
#ifdef ADC1
    	__HAL_RCC_ADC1_CLK_ENABLE();
#endif
#ifdef ADC2
    	__HAL_RCC_ADC2_CLK_ENABLE();
#endif
        GPIO_Mode_x  = MODE_ANALOG;
        GPIO_PuPd_x  = GPIO_NOPULL;
    }
#endif
    else if(pinMode_x == OUTPUT)
    {
        GPIO_Mode_x  = MODE_OUTPUT;
        GPIO_OType_x = OUTPUT_PP;
        GPIO_Mode_x = GPIO_Mode_x | GPIO_OType_x;

        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == OUTPUT_OPEN_DRAIN)
    {
        GPIO_Mode_x  = MODE_OUTPUT;
        GPIO_OType_x = OUTPUT_OD;
        GPIO_Mode_x = GPIO_Mode_x | GPIO_OType_x;

        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else if(pinMode_x == OUTPUT_AF)
    {
        GPIO_Mode_x  = MODE_AF;
        GPIO_OType_x = OUTPUT_PP;
        GPIO_Mode_x = GPIO_Mode_x | GPIO_OType_x;

        GPIO_PuPd_x  = GPIO_NOPULL;
    }
    else
    {
    	GPIO_PuPd_x  = GPIO_NOPULL;	//针对pinMode_x 为 GPIO_MODE_IT_XXX
        return;
    }



    GPIO_InitStruct.Pin = GPIO_PIN_X;
    GPIO_InitStruct.Mode = GPIO_Mode_x;
    GPIO_InitStruct.Speed = GPIO_Speed_x;
    GPIO_InitStruct.Pull = GPIO_PuPd_x;

//    初始化GPIO
    HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
//    初始化GPIO
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOx, ENABLE);
//    GPIO_Init(GPIOx, &GPIO_InitStruct);
}

/**
  * @brief  获取当前引脚对应的GPIOx编号
  * @param  Pin: 引脚编号
  * @retval 无
  */
uint8_t GPIO_GetPortNum(uint8_t Pin)
{
#ifdef GPIOA
    if(PIN_MAP[Pin].GPIOx == GPIOA)return 0;
#endif
#ifdef GPIOB
    else if(PIN_MAP[Pin].GPIOx == GPIOB)return 1;
#endif
#ifdef GPIOC
    else if(PIN_MAP[Pin].GPIOx == GPIOC)return 2;
#endif
#ifdef GPIOD
    else if(PIN_MAP[Pin].GPIOx == GPIOD)return 3;
#endif
#ifdef GPIOE
    else if(PIN_MAP[Pin].GPIOx == GPIOE)return 4;
#endif
#ifdef GPIOF
    else if(PIN_MAP[Pin].GPIOx == GPIOF)return 5;
#endif
#ifdef GPIOG
    else if(PIN_MAP[Pin].GPIOx == GPIOG)return 6;
#endif
#ifdef GPIOH
    else if(PIN_MAP[Pin].GPIOx == GPIOH)return 7;
#endif
#ifdef GPIOI
    else if(PIN_MAP[Pin].GPIOx == GPIOI)return 8;
#endif
#ifdef GPIOJ
    else if(PIN_MAP[Pin].GPIOx == GPIOJ)return 9;
#endif
#ifdef GPIOK
    else if(PIN_MAP[Pin].GPIOx == GPIOK)return 10;
#endif
    else return 0xFF;
}

/**
  * @brief  获取当前引脚对应的 PinSource
  * @param  GPIO_PIN_X: GPIO对应位
  * @retval 无
  */
uint8_t GPIO_GetPinSource(uint16_t GPIO_PIN_X)
{
    uint16_t PinSource = 0;
    while(GPIO_PIN_X > 1)
    {
        GPIO_PIN_X >>= 1;
        PinSource++;
    }
    return PinSource;
}

/**
  * @brief  获取当前引脚对应的编号
  * @param  Pin: 引脚编号
  * @retval 无
  */
uint8_t GPIO_GetPinNum(uint8_t Pin)
{
    return GPIO_GetPinSource(PIN_MAP[Pin].GPIO_Pin);
}
