/*
 * Page.hpp
 *
 *  Created on: 2021年4月20日
 *      Author: OldGerman
 */

#ifndef INC_PAGE_HPP_
#define INC_PAGE_HPP_
#include "Colum.hpp"
#include <list>
#include <vector>
#include "oled_init.h"
//#include "font24x32numbers.h"
#include "Settings.h"
//#include "Threads.hpp"
#include <Buttons.hpp>
//#include "u8g2_simsun_9_fntodgironchinese.h"
#include "Arduino.h" //提供bit操作宏
#define mymax(a,b) ((a) > (b) ? (a) : (b))
#define mymin(a,b) ((a) < (b) ? (a) : (b))


#define MENU_DELAY 50	//ms 菜单刷新时间

#define NON_CATTOON 1
#ifdef __cplusplus
#include <algorithm>
#include <cstring>
void cartoonFreshColums(bool Dir, uint8_t Steps = 4);
void drawLogoAndVersion(char firmwareMark);


class Page {
public:
	Page() {};
	Page(std::vector<Colum> *columVec);
	virtual ~Page() {}
	static void flashPage();
	static void columValAdjust(Colum *ptrColum);
	//绘制能显示在oled屏幕可见范围内的colums
	void drawColums();
	//绘制一个colum
	//selected 可能为 0，1，2。 其中2为颜色叠加模式
	void drawColum(Colum *ptrColum, int8_t y, uint8_t selected);
	static void resetPageIndex(bool reset);
	static void drawNumber(uint8_t x, uint8_t y, uint16_t number, uint8_t places);
	static bool stateTimeOut();
//	static bool stateTimeOut2();
	static Colum* getColumsSelected() { return *ptrPage->_itrColums; }
	//求当前_itrColums是当前_listColums的第几个元素，0表示第一个, 测试OK
	static int num_of_itrColum() { return *ptrPage->_itrColums - *ptrPage->_listColums.begin(); }
	//绘制icons，未使用
	void drawIcon() {;}
	static void cartoonFreshColums(bool Dir, uint8_t Steps = 4);
	static void cartoonFreshFonts(bool Dir = 0, uint8_t Steps = 4);
	std::list<Colum*> _listColums;
	static AutoValue indexColums;	//用于索引当前选中的colum在oled上的y坐标位置
	static Page *ptrPage;
	static Page *ptrPagePrev;
	static Page *homePage;
	static std::list<Page *> ptrPageList;
	static bool timeOut;			//级联菜单共用返回上级的停顿感延时的标记
	static uint8_t valIndex;		//用于临时储存Page::indexColums的val值

private:
	std::list<Colum*>::iterator _itrColums;
	//const uint8_t *_Icon;
	Page *_nextPage;
	Page *_prevPage;
	uint8_t _numColums;
};

extern Page pageHomePage;
extern std::vector<uint16_t> *ptrAutoValueLanguageVals;
void   enterSettingsMenu();
#endif
#endif	/* INC_PAGE_HPP_ */
