/*
 * Page.cpp
 *
 *  Created on: 2021年4月20日
 *      Author: OldGerman
 */

#include "Page.hpp"

#define resetWatchdog(...)

void   enterSettingsMenu()
{
	Page::flashPage();
}

Page::Page(std::vector<Colum> *columVec) { //默认指向的上一个Page是自己
	_numColums = columVec->size();				//获取colums个数
	std::vector<Colum>::const_iterator  columIter;
	for (columIter = columVec->begin(); columIter != columVec->end();
			columIter++)
		_listColums.push_back(&(*columIter));	//std::list元素为Colum对象指针	//使用了STL内存分配器，需要系统堆空间
	_itrColums = _listColums.begin(); //将选中的栏还原为第一个
}

void Page::flashPage() {
	buttons = BUTTON_NONE;
	osDelay(400);
	bool firshInflashPage = 1;
	ptrPageList.push_back(ptrPage);					//进入菜单首先把honePage对象添加到链表末尾

	for (;;) {
		valIndex = *(uint8_t*)(indexColums.val);
		buttons = getButtonState();

		switch (buttons) {
		case BUTTON_A_SHORT:
		case BUTTON_A_LONG:
			if (*(ptrPage->_itrColums) == ptrPage->_listColums.back()) {
				ptrPage->_itrColums = ptrPage->_listColums.begin();
				for(uint8_t cntICO = 0; cntICO < cntIndexColumsOffsset; cntICO++) {
					indexColums--;
				}
			}else{
				ptrPage->_itrColums++;
				indexColums++;
			}
			break;
		case BUTTON_B_SHORT:
		case BUTTON_B_LONG:
			if (ptrPage->_itrColums == ptrPage->_listColums.begin()) {
				ptrPage->_itrColums = ptrPage->_listColums.end();
				ptrPage->_itrColums--;
				for(uint8_t cntICO = 0; cntICO < cntIndexColumsOffsset; cntICO++) {
					indexColums++;
				}
			}else{
				ptrPage->_itrColums--;
				indexColums--;
			}
			break;
		case BUTTON_OK_LONG:
			break;
		case BUTTON_OK_SHORT:
			/*支持三级及以上菜单*/
			if ((*ptrPage->_itrColums)->nextPage != nullptr)
			{
				if(firshInflashPage) {
					firshInflashPage = 0;
				}else{
					ptrPageList.push_back(ptrPage);
				}

				ptrPage = (*ptrPage->_itrColums)->nextPage; //当前页面指针指向当前页面指针指向的Colum的下级菜单
				resetPageIndex(false);
			}
			else
			{
				const Colum *ptrColum = ptrPage->getColumsSelected();
				if (ptrColum->funPtr != nullptr && ptrColum->ptrAutoValue == nullptr)
						ptrColum->funPtr();	//跳去执行函数指针的函数
				else
				//执行colums的改值函数
					columValAdjust(*ptrPage->_itrColums);
			}
			break;
		default:
			break;
		}

		const uint8_t lastExitCnt = 1;
		static uint8_t lastExit = lastExitCnt;

		if (stateTimeOut() && (buttons == BUTTON_OK_LONG/* || moveDetected)*/)) {
#if DoubleMenu	/*仅支持二级菜单*/
			ptrPage = homePage;
#else			/*支持三级及以上菜单*/
			ptrPage = ptrPageList.back();	//此时ptrPage才是前一个Page*
			if(ptrPage != ptrPageList.front()) //防止越界删除，实测有效
				ptrPageList.pop_back();	//先删除尾端Page
#endif
			resetPageIndex(false);
		}

#if 0
		// 矩形动画偏移	//暂时支持两级栏
		//....占用2KBflash，太大了算了
#endif

		//taskENTER_CRITICAL();
		ptrPage->drawColums();
		//taskEXIT_CRITICAL();
		u8g2.sendBuffer();
		osDelay(MENU_DELAY);
#if 1
		//到最父级的homePage页才退出本函数块
		if(ptrPage == ptrPageList.front() &&
				stateTimeOut() &&
				(buttons == BUTTON_OK_LONG/* || moveDetected)*/))
		{
			--lastExit;
			if(!lastExit )
			{
				lastExit = lastExitCnt;
//				moveDetected = false;
				break;
			}
		}
#endif
		resetWatchdog();
	}
}

void Page::columValAdjust(const Colum *ptrColum) {
	AutoValue *ptrAutoValue = ptrColum->ptrAutoValue;
	uint32_t lastChange = xTaskGetTickCount();
	//入口处执行函数指针的不用执行else部分
	if (ptrColum->str == nullptr)
		return;

	if (ptrColum->funLoc == LOC_ENTER) {
		ptrColum->funPtr();
	} else {

		for (;;) {
			//u8g2.clearBuffer();	//保留上级for循环刷新的buffer，本节只刷新值
			buttons = getButtonState();
			if (buttons)
				lastChange = xTaskGetTickCount();
			AutoValue::buttonState = buttons;

			//taskENTER_CRITICAL();	//临界段代码，防止绘图时被打乱出现错位
			switch (buttons) {
			case BUTTON_A_LONG:
			case BUTTON_A_SHORT:
				(*ptrAutoValue)--;//AutoValue::operator--()在内部判断buttons长按短按
				if (ptrColum->funLoc == LOC_CHANGE)
					ptrColum->funPtr();
				break;
			case BUTTON_B_LONG:
			case BUTTON_B_SHORT:
				(*ptrAutoValue)++;
				if (ptrColum->funLoc == LOC_CHANGE)
					ptrColum->funPtr();
				break;
			default:
				break;
			}

			uint16_t y = *(uint16_t*)(indexColums.val);
			ptrPage->drawColum(ptrColum, y, 1);
			y += 1;
			u8g2.setDrawColor(0);
			u8g2.drawStr(82, y, "*");	//绘制更改标记
			//taskEXIT_CRITICAL();
			u8g2.sendBuffer();

			if ((xTaskGetTickCount() - lastChange > 2000)
					|| (buttons == BUTTON_OK_SHORT)) {
				if (ptrColum->funLoc == LOC_EXTI)
					ptrColum->funPtr();
				if (ptrColum->ptrAutoValue != nullptr) {
					saveSettings();
					resetSettings();
					restoreSettings();
				}
				return;
			}

			osDelay(MENU_DELAY);
		}
	}
}

void Page::drawColums() {
	//绘制被选中的colum
	drawColum(*_itrColums, *(uint8_t*)(indexColums.val), 1);
	//绘制被选中colum上面的colum
	for (uint8_t i = indexColums.lower; i < *(uint8_t*)(indexColums.val);) {
		i += indexColums.shortSteps;
		drawColum(
				*_itrColums
						- (*(uint8_t*)(indexColums.val) - indexColums.lower)
								/ indexColums.shortSteps
						+ (i / indexColums.shortSteps) - 1,
				i - indexColums.shortSteps, 0);
	}
	//绘制被选中colum下面的colum
	for (uint8_t i = 0; i < indexColums.upper - *(uint8_t*)(indexColums.val);) {
		i += indexColums.shortSteps;
		drawColum(*_itrColums + (i / indexColums.shortSteps),
				*(uint8_t*)(indexColums.val) + i, 0);
	}
}

void Page::drawColum(const Colum *ptrColum, int8_t y, uint8_t selected) {
		//绘制反显矩形
		if(selected != 2) {
			u8g2.setDrawColor(selected);
			u8g2.drawBox(0, y, 64, 16);
			u8g2.setDrawColor(!selected);
		}
		else
		{
			//不要绘制黑色矩形，动画过渡会闪屏
			//u8g2.setDrawColor(!selected);
		    //u8g2.drawBox(0, y, 64, 16);

			u8g2.setDrawColor(selected); //color 2模式
		}

		//绘制栏名称字符,宋体UTF-8
		y += (2 + 11);	//偏移字符串y坐标
		int8_t y1 = y, y2 = y, y3 = y;

		if (ptrColum->str != nullptr) {
			u8g2.setFont(u8g2_simsun_9_fontUniSensorChinese);	//12x12 pixels
			u8g2.setFontRefHeightText();
			u8g2.drawUTF8(1, y, ptrColum->str);	//打印中文字符，编译器需要支持UTF-8编码，显示的字符串需要存为UTF-8编码
		}

#if 1
		if (ptrColum->ptrAutoValue != nullptr) {
			//绘制栏详情字符

			if (!(*ptrColum->ptrAutoValue).valueIsBool() ||
					(ptrColum->ptrColumVal2Str != nullptr)) 	//针对只有0和1两个值map string的情况
			{
				if(ptrColum->ptrColumVal2Str != nullptr)
				{
					std::map<uint16_t, const char*>::iterator itr = ptrColum->ptrColumVal2Str->find(*(uint16_t*)(ptrColum->ptrAutoValue)->val);
					u8g2.drawUTF8( 128 -  strlen(itr->second) / 3 /*"中" = 3 "中文" = 6 "中文字" = 9;=*/
							* 12/*12=字体宽度*/ -3 /*边缘偏移*/, y1, itr->second);
				}
				else
				{
					// 修改字体为非中文字体
					u8g2.setFont(u8g2_font_unifont_tr);	//10x7 pixels
					u8g2.setFontRefHeightText();
#if 1
					Page::drawNumber(113 - (ptrColum->ptrAutoValue->places) * 6, y2,
							*(uint16_t*)(ptrColum->ptrAutoValue)->val,
							(ptrColum->ptrAutoValue)->places);
#endif
					if (ptrColum->unit != nullptr)
						u8g2.drawStr(119, y2, ptrColum->unit);	//	绘制单位
				}
			}
			else	//为“虚拟bool类型”，特殊处理
			{
				u8g2.setFont(u8g2_font_unifont_tr);	//10x7 pixels
				u8g2.setFontRefHeightText();
				(*(uint8_t*)(ptrColum->ptrAutoValue)->val == true) ?
						u8g2.drawStr(111, y3, "ON") :
						u8g2.drawStr(103, y3, "OFF");
			}
	}
#endif
}

void Page::resetPageIndex(bool reset) {
	if (reset) {
		//强制指向第一个栏
		ptrPage->_itrColums = ptrPage->_listColums.begin();
		(*(uint8_t*)(indexColums.val) = 0);
	} else
		//尾端检查indexColums防止非法访问
		(*(ptrPage->_itrColums) == ptrPage->_listColums.back()) ?
				(*(uint8_t*)(indexColums.val) = indexColums.upper) :
				(*(uint8_t*)(indexColums.val) = 0);
}

void Page::drawNumber(uint8_t x, uint8_t y, uint16_t number,
		uint8_t places) {
	char buffer[7] = { 0 };
	//sprintf(buffer, "%06d" , number);
	sprintf(buffer, "%6d", number);
	uint8_t cntFirstNum = 0;
	uint8_t i = 0;
	while (i < 7) {
		if (buffer[i] != ' ') {
			cntFirstNum = i;
			break;
		}
		++i;
	}
	uint8_t cntNum = 6 - cntFirstNum;
	u8g2.drawStr(x, y, buffer + cntFirstNum - (places - cntNum));
	//u8g2.drawUTF8(x, y, buffer + cntFirstNum - (places - cntNum));
}

bool Page::stateTimeOut() {
	uint32_t previousState = xTaskGetTickCount();
	static uint32_t previousStateChange = xTaskGetTickCount();
	if ((previousState - previousStateChange) > 500) {	///	这个500决定向父级菜单递归的阻塞感
		previousStateChange = previousState;
		return true;
	}
	return false;
}

#if CARTOON_COLUM
/**
  * @brief  栏条矩形动画偏移函数，仅支持两级菜单栏栏滚动
  * @param  Dir 滚动方向，0向上，1向下
  * @param Steps 动画步幅除数：范围{0, 1, 2, 4, 8, 16}，默认为4步幅
  * @retval None
  */
void Page::cartoonFreshColums(bool Dir, uint8_t Steps)
{
	uint8_t *ptrBuffer = u8g2.getBufferPtr();	//得到U8g2的屏幕显示缓冲区地址，当前总缓冲区大小为 128 x 8 x 4 bit
	uint8_t *ptrRecFront;
	uint8_t *ptrRecBack;
	if(Dir) {
		ptrRecFront = ptrBuffer;
		ptrRecBack = ptrBuffer + 128 * 2;
	}
	else {
		ptrRecFront = ptrBuffer + 128 * 1;
		ptrRecBack = ptrBuffer + 128 * 3;

	}

	uint8_t cntShowFrame = 0;
	uint8_t Bit;

	for (uint8_t cntY = 0; cntY < 2; cntY++)
	{
		resetWatchdog();
		//加128，屏幕上表现为自动换行
		int cnt = cntY * 128;
		if(Dir) {
			ptrRecFront += cnt;
			ptrRecBack += cnt;
		}else {
			ptrRecFront -= cnt;
			ptrRecBack -= cnt;
		}
		uint8_t cntBitCrtl;
		for (uint8_t cntBit = 0; cntBit < 8; cntBit++)
		{
			cntBitCrtl = 7 - cntBit;
			if(Dir)
				Bit = cntBit;
			else
				Bit = cntBitCrtl;

			uint8_t cntX;
			for(cntX = 0; cntX < 128; cntX ++)
			{
				bitWrite(*ptrRecFront, Bit, !bitRead(*ptrRecFront, Bit));
				bitWrite(*ptrRecBack, Bit, !bitRead(*ptrRecBack, Bit));
				ptrRecFront++;
				ptrRecBack++;
			}
			ptrRecFront -= 128;
			ptrRecBack -= 128;
			//刷新buffer即24帧，约2秒
			cntShowFrame = (cntShowFrame + 1) % Steps;
			if(!cntShowFrame) {
				u8g2.sendBuffer();
				osDelay(10);
			}
		}
	}
}

/**
  * @brief  栏条字体动画偏移函数，仅支持两级菜单栏栏滚动
  * @param  Dir 滚动方向，0向上，1向下
  * @param Steps 动画步幅除数：范围{0, 1, 2, 4, 8, 16}，默认为4
  * @retval None
  */
void Page::cartoonFreshFonts(bool Dir, uint8_t Steps)
{
	u8g2.setDrawColor(1);
	u8g2.setFontMode(1);

	//若valIndex=16，则 _itrColums相比当前显示选中的colum已经向下迭代一位
	//若valIndex=0，则 _itrColums相比当前显示选中的colum已经向上迭代一位
	std::list<Colum*>::iterator itrColums = ptrPage->_itrColums;

	if(valIndex == 16) {
		for(uint8_t cntY = 0; cntY < 16;) {
			itrColums = ptrPage->_itrColums;
			--itrColums;
			--itrColums;
			//绘制底图矩形
			//u8g2.clearBuffer();
			u8g2.setDrawColor(1);
			u8g2.drawBox(0, 16, 128, 16);
			u8g2.setDrawColor(0);
			u8g2.drawBox(0, 0, 128, 16);

			u8g2.setFontPosBottom();
			int8_t cntYCase = 15 - cntY -2;
			if(cntYCase >= 0)
				ptrPage->drawColum(*itrColums, cntYCase, 2);
			++itrColums;
			u8g2.setFontPosTop();	//还原字体上对其
			cntYCase = 15 - cntY;
			if(cntYCase >= 0)
				ptrPage->drawColum(*itrColums, cntYCase, 2);
			++itrColums;
			ptrPage->drawColum(*itrColums, 31 - cntY, 2);

			u8g2.sendBuffer();
			osDelay(10);

			cntY += Steps;
		}
	}
	else if(valIndex == 0) {
		for(uint8_t cntY = 0; cntY < 16;) {
			itrColums = ptrPage->_itrColums;
			++itrColums;
			++itrColums;
			//绘制底图矩形
			//u8g2.clearBuffer();
			u8g2.setDrawColor(1);
			u8g2.drawBox(0, 0, 128, 16);
			u8g2.setDrawColor(0);
			u8g2.drawBox(0, 16, 128, 16);

			u8g2.setFontPosTop();	//还原字体上对其
			int8_t cntYCase = 15 + cntY + 1;
			if(cntYCase <= 31)
				ptrPage->drawColum(*itrColums, cntYCase, 2);
			--itrColums;
			ptrPage->drawColum(*itrColums, cntY + 1, 2);
			--itrColums;
			u8g2.setFontPosBottom();
			cntYCase = cntY -2;
			if(cntYCase >= 0)
				ptrPage->drawColum(*itrColums, cntYCase, 2);
			u8g2.setFontPosTop();
			u8g2.sendBuffer();
			osDelay(10);

			cntY += Steps;
		}
	}
	u8g2.setFontMode(0);
}

#endif


// 临时健忘笔记
/**
 * C++对象数组构造函数
 * 要使用需要多个参数的构造函数，则初始化项必须釆用函数调用的形式。
 * 例如，来看下面的定义语句，它为 3 个 Circle 对象的每一个调用 3 个参数的构造函数：
 * Circle circle[3] = {Circle(4.0, 2, 1),Circle(2.0, 1, 3),Circle (2.5, 5, -1) };
 * 没有必要为数组中的每个对象调用相同的构造函数。例如，以下语句也是合法的：
 * Circle circle [3] = { 4.0,Circle (2.0, 1, 3),2.5 };
 */
/**
 * array对象和数组存储在相同的内存区域（栈）中，vector对象存储在自由存储区（堆）
 */
